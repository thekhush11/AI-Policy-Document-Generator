import os
from dotenv import load_dotenv
from huggingface_hub import snapshot_download

# Load environment variables
dotenv_path = os.path.join(os.path.dirname(__file__), "../../.env")
load_dotenv(dotenv_path)

MODEL_NAME = os.getenv("MODEL_NAME", "google/flan-t5-base")  # default
HF_TOKEN = os.getenv("HF_TOKEN")

print(f"Downloading model: {MODEL_NAME} ...")

snapshot_download(
    repo_id=MODEL_NAME,
    local_dir="C:/Users/aitr2/models",
    token=HF_TOKEN
)

print("✅ Model downloaded successfully!")