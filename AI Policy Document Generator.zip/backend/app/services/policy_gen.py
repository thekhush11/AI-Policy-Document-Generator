# backend/app/services/policy_gen.py
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch

MODEL_PATH = "google/flan-t5-base"

# load once
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_PATH)

def generate_policy(domain: str, region: str, scope: str, tone: str) -> str:
    prompt = (f"""
        You are an expert government policy writer.
        Create a {scope} for {domain} in {region}.
        Tone: {tone}.

        The policy must include these sections with detailed content for each:

        1. Executive Summary:
        - Provide a short summary explaining the purpose of the policy and its expected impact.

        2. Objectives:
        - List 4-6 specific objectives with short explanations for each.

        3. Ethical Principles:
        - Explain 3-5 ethical principles guiding this policy, with examples.

        4. Legal/Regulatory Framework:
        - Provide relevant laws or regulations and how they will be applied.

        5. Implementation Strategy:
        - Give step-by-step actions, responsible parties, and timelines.

        6. Risks & Mitigation:
        - List potential risks and detailed mitigation strategies.

        7. Monitoring & Evaluation:
        - Describe methods, KPIs, and frequency of monitoring.

        Write full sentences and detailed explanations for each section.
        """)

    inputs = tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True)
    output_ids = model.generate(**inputs, max_new_tokens=500)
    policy_text = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    return policy_text