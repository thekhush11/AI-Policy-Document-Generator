# backend/app/api/routes.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from backend.app.services.policy_gen import generate_policy
from backend.app.utils.formatter import build_docx_bytes
import base64

router = APIRouter()

class PolicyRequest(BaseModel):
    domain: str
    region: str
    scope: str
    tone: str

@router.post("/generate_policy")
async def generate_policy_route(req: PolicyRequest):
    try:
        # call HF-based generator
        policy_text = generate_policy(
            domain=req.domain,
            region=req.region,
            scope=req.scope,
            tone=req.tone,
        )

        # create docx bytes
        docx_bytes = build_docx_bytes(policy_text, title=f"{req.domain} - Policy Draft")
        docx_b64 = base64.b64encode(docx_bytes).decode("utf-8")

        return {"policy": policy_text, "docx_base64": docx_b64}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
