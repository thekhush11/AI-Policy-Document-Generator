# backend/app/utils/formatter.py
from io import BytesIO
from docx import Document

def build_docx_bytes(text: str, title: str = "Policy Document") -> bytes:
    """
    Create a .docx file in-memory from plain text and return bytes.
    The function splits by double newlines to make paragraphs.
    """
    doc = Document()
    doc.add_heading(title, level=1)

    # split by two newlines into sections
    sections = text.split("\n\n")
    for sec in sections:
        # If section looks like "Heading:\nContent", format heading bold
        if ":" in sec:
            first_line, *rest = sec.split("\n", 1)
            # treat first_line as a heading
            p = doc.add_paragraph()
            run = p.add_run(first_line.strip())
            run.bold = True
            if rest:
                p = doc.add_paragraph(rest[0].strip())
        else:
            doc.add_paragraph(sec.strip())

    bio = BytesIO()
    doc.save(bio)
    bio.seek(0)
    return bio.read()
