from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import os

MODEL_NAME = os.getenv("MODEL_NAME")
assert MODEL_NAME is not None, "MODEL_NAME must be set in .env"

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)

# Make pipeline
generator = pipeline("text-generation", model=model, tokenizer=tokenizer)

def generate_response(prompt: str, max_length: int = 200):
    output = generator(prompt, max_length=max_length, num_return_sequences=1)
    return output[0]["generated_text"]