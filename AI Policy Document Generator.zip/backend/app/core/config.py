# backend/app/core/config.py
import os
from dotenv import load_dotenv

# Step 1: backend ka parent folder (app ka parent hi backend hai)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # backend/app/core
BASE_DIR = os.path.dirname(os.path.dirname(BASE_DIR))  # backend

# Step 2: backend/.env ka path
dotenv_path = os.path.join(BASE_DIR, ".env")
print(f"DEBUG: Forcing .env path = {dotenv_path}")

# Step 3: load .env
load_dotenv(dotenv_path)

class Settings:
    HF_API_KEY: str | None = os.getenv("HF_API_KEY")
    MODEL_NAME: str | None = os.getenv("MODEL_NAME", "mistralai/Mistral-7B-Instruct-v0.3")

    def __init__(self):
        print(f"DEBUG: HF_API_KEY loaded = {self.HF_API_KEY}")
        print(f"DEBUG: MODEL_NAME loaded = {self.MODEL_NAME}")

settings = Settings()
