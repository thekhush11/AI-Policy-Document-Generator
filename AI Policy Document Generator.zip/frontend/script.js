document.addEventListener("DOMContentLoaded", () => {
  const API_URL = "http://127.0.0.1:8000/api/generate_policy";

  const form = document.getElementById("policyForm");
  const outputEl = document.getElementById("result");
  const policyTextEl = document.getElementById("policyText");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    // read values
    const domain = document.getElementById("domain").value.trim();
    const region = document.getElementById("region").value.trim();
    const scope = document.getElementById("scope").value;
    const tone = document.getElementById("tone").value;

    // show loading UI
    policyTextEl.textContent = "Generating policy... (this may take a few seconds)";
    outputEl.style.display = "block";

    try {
      const resp = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain, region, scope, tone }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.detail || `Server returned ${resp.status}`);
      }

      const data = await resp.json();

      // show policy text
      policyTextEl.textContent = data.policy || "No policy returned.";

      // handle docx download button
      const existingBtn = document.getElementById("downloadBtn");
      if (existingBtn) existingBtn.remove();

      if (data.docx_base64) {
        const downloadBtn = document.createElement("button");
        downloadBtn.id = "downloadBtn";
        downloadBtn.textContent = "Download .docx";
        downloadBtn.style.marginTop = "12px";
        downloadBtn.addEventListener("click", () => {
          const b64 = data.docx_base64;
          const link = document.createElement("a");
          link.href =
            "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," +
            b64;
          const safeName = (domain || "policy").replace(/\s+/g, "_");
          link.download = `${safeName}_policy.docx`;
          document.body.appendChild(link);
          link.click();
          link.remove();
        });
        outputEl.appendChild(downloadBtn);
      }
    } catch (err) {
      console.error("Error fetching policy:", err);
      policyTextEl.textContent = "Error: " + err.message;
    }
  });
});