from dataclasses import dataclass
from typing import List, Dict

# --- Lightweight knowledge base ---
METHODS = [
    'Drip',
    'Sprinkler',
    'Surface (Furrow/Basin)',
    'Subsurface Drip',
    'Center Pivot',
    'Rainwater Harvesting + Storage',
]

CROP_KC = {
    'Wheat': 1.15,
    'Rice (paddy)': 1.2,
    'Maize': 1.05,
    'Cotton': 1.2,
    'Vegetables': 1.1,
    'Orchard/Fruit': 0.95,
    'Sugarcane': 1.25,
}

REGION_RAINFALL = {
    "Andhra Pradesh": 850,
    "Arunachal Pradesh": 2200,
    "Assam": 1500,
    "Bihar": 950,
    "Chhattisgarh": 1100,
    "Goa": 3000,
    "Gujarat": 800,
    "Haryana": 650,
    "Himachal Pradesh": 1250,
    "Jharkhand": 1200,
    "Karnataka": 900,
    "Kerala": 1200,
    "Madhya Pradesh": 950,
    "Maharashtra": 900,
    "Manipur": 1800,
    "Meghalaya": 2500,
    "Mizoram": 2500,
    "Nagaland": 1800,
    "Odisha": 1300,
    "Punjab": 700,
    "Rajasthan": 500,
    "Sikkim": 2000,
    "Tamil Nadu": 750,
    "Telangana": 900,
    "Tripura": 2000,
    "Uttar Pradesh": 850,
    "Uttarakhand": 1300,
    "West Bengal": 1400,
    # Union Territories
    "Andaman and Nicobar": 3000,
    "Chandigarh": 1000,
    "Dadra and Nagar Haveli": 1400,
    "Daman and Diu": 1200,
    "Delhi": 800,
    "Jammu and Kashmir": 1200,
    "Ladakh": 100,
    "Lakshadweep": 3000,
    "Puducherry": 1200
}

def _estimate_avg_rain(region: str, input_rain: float = 0.0) -> float:
    """Return average seasonal rainfall for the region.
       Use input if provided, else default region value, else 750 mm.
    """
    if input_rain > 0:
        return input_rain
    return REGION_RAINFALL.get(region, 750)

SOIL_TYPES = ['Sand', 'Loam', 'Clay']
SLOPE_CLASSES = ['Flat', 'Gentle', 'Steep']
SALINITY = ['Low', 'Medium', 'High']

@dataclass
class Inputs:
    crop: str
    region: str
    area_ha: float
    soil: str
    slope: str
    avg_rain_mm: float
    water_source: str
    budget_level: str
    labor_level: str
    salinity: str
    objective: str

# Scoring logic (same as your previous _score_method)
def _score_method(inp: Inputs) -> Dict[str, float]:
    scores = {m: 0.0 for m in METHODS}
    # Crop preferences
    if inp.crop in ['Vegetables', 'Orchard/Fruit']:
        scores['Drip'] += 3
        scores['Subsurface Drip'] += 2
    if inp.crop == 'Rice (paddy)':
        scores['Surface (Furrow/Basin)'] += 2
        scores['Sprinkler'] -= 1
    if inp.crop in ['Wheat', 'Maize']:
        scores['Sprinkler'] += 2
        scores['Center Pivot'] += 1
    # Soil impacts
    if inp.soil == 'Sand':
        scores['Drip'] += 2
        scores['Sprinkler'] += 1
        scores['Surface (Furrow/Basin)'] -= 1
    elif inp.soil == 'Loam':
        scores['Sprinkler'] += 1
        scores['Drip'] += 1
    elif inp.soil == 'Clay':
        scores['Surface (Furrow/Basin)'] += 2
        scores['Sprinkler'] -= 1
    # Slope
    if inp.slope == 'Flat':
        scores['Surface (Furrow/Basin)'] += 1
        scores['Center Pivot'] += 1
    elif inp.slope == 'Gentle':
        scores['Sprinkler'] += 1
        scores['Drip'] += 1
    else:
        scores['Drip'] += 2
        scores['Surface (Furrow/Basin)'] -= 2
    # Rainfall
    if inp.avg_rain_mm < 500:
        scores['Drip'] += 2
        scores['Rainwater Harvesting + Storage'] += 2
    elif inp.avg_rain_mm > 1200:
        scores['Surface (Furrow/Basin)'] += 1
        scores['Sprinkler'] += 1
    # Water source
    if inp.water_source == 'Borewell':
        scores['Drip'] += 2
    if inp.water_source == 'Rainfed':
        scores['Rainwater Harvesting + Storage'] += 3
    # Budget
    if inp.budget_level == 'Low':
        scores['Surface (Furrow/Basin)'] += 2
        scores['Drip'] -= 1
        scores['Subsurface Drip'] -= 2
        scores['Center Pivot'] -= 2
    elif inp.budget_level == 'High':
        scores['Drip'] += 2
        scores['Subsurface Drip'] += 1
        scores['Center Pivot'] += 1
    # Labor
    if inp.labor_level == 'Low':
        scores['Drip'] += 1
        scores['Center Pivot'] += 1
        scores['Surface (Furrow/Basin)'] -= 1
    # Salinity
    if inp.salinity == 'High':
        scores['Drip'] += 1
        scores['Sprinkler'] -= 1
    # Objective
    if inp.objective == 'Save Water':
        scores['Drip'] += 3
        scores['Subsurface Drip'] += 1
    elif inp.objective == 'Yield Max':
        scores['Sprinkler'] += 2
        scores['Center Pivot'] += 1
        scores['Drip'] += 1
    else:
        scores['Surface (Furrow/Basin)'] += 3
    return scores

def _method_notes(method: str) -> List[str]:
    notes = {
        'Drip': ['High water-use efficiency (up to ~90%).','Best for row crops, orchards, vegetables.','Requires filtration; periodic flushing.'],
        'Sprinkler': ['Uniform application; suitable for cereals & oilseeds.','Wind can reduce uniformity; moderate energy need.'],
        'Surface (Furrow/Basin)': ['Lowest capex; higher labor and water requirement.','Good on clays and level fields.'],
        'Subsurface Drip': ['Very high efficiency; buried laterals reduce evaporation.','Higher initial cost; precise layout needed.'],
        'Center Pivot': ['Automated, low labor; suited for large flat fields.','Capex high; circular coverage footprint.'],
        'Rainwater Harvesting + Storage': ['Adds resilience under rainfed conditions.','Combine with drip or sprinkler for supplemental irrigation.'],
    }
    return notes.get(method, [])

def _starter_kit(method: str, inp: Inputs) -> List[str]:
    kits = {
        'Drip': ['Sand + screen filter unit','Mainline + submain','Laterals 2 LPH @30–40 cm','Venturi/fertigation tank','Pressure gauge + valves'],
        'Sprinkler': ['Pump (head 20–30 m)','Mainline + risers','Impact/rotary sprinklers @12–18 m','Pressure regulator'],
        'Surface (Furrow/Basin)': ['Field leveling tools','Furrow/basin layout tools','Field channels and turnout structures'],
        'Subsurface Drip': ['Disc filter + sand filter','Buried drip laterals (20–30 cm depth)','Air/vacuum relief valves'],
        'Center Pivot': ['Pivot machine','Pump + filtration','End gun (optional)'],
        'Rainwater Harvesting + Storage': ['Rooftop/field bunding works','Silt trap + first-flush device','Storage tank/pond lining'],
    }
    return kits.get(method, [])

def _estimate_water_need_mm(inp: Inputs) -> float:
    kc = CROP_KC.get(inp.crop, 1.0)
    base_et0 = 4.5
    season_days = 110 if inp.crop in ['Wheat', 'Maize'] else 130
    gross = base_et0 * kc * season_days
    effective_rf = 0.5 * inp.avg_rain_mm
    need = max(0.0, gross - effective_rf)
    return round(need, 1)

def _as_report(inp: Inputs, water_need_mm: float, volume_m3: float, recs: List[Dict]) -> str:
    lines = []
    lines.append('# Advisory Summary')
    lines.append(f"Crop: {inp.crop} | Area: {inp.area_ha} ha | Soil: {inp.soil} | Slope: {inp.slope}")
    lines.append(f"Rainfall: {inp.avg_rain_mm} mm | Region: {inp.region} | Source: {inp.water_source} | Salinity: {inp.salinity}")
    lines.append(f"Objective: {inp.objective} | Budget: {inp.budget_level} | Labor: {inp.labor_level}")
    lines.append('')
    lines.append('# Seasonal Water Requirement')
    lines.append(f"Net irrigation requirement: {water_need_mm} mm")
    lines.append(f"Seasonal volume for field: {volume_m3} m³\n")
    lines.append('# Recommended Methods (Top 3)')
    for i, r in enumerate(recs, 1):
        lines.append(f"## {i}. {r['method']} (score {r['score']})")
        for n in r['why']:
            lines.append(f"- {n}")
        if r['starter_kit']:
            lines.append('  Starter kit:')
            for k in r['starter_kit']:
                lines.append(f"  - {k}")
        lines.append('')
    lines.append('# Basic Scheduling Tips')
    lines.append('- Irrigate early morning or late evening to reduce evaporation.')
    lines.append('- Monitor soil moisture weekly; adjust with rainfall events.')
    lines.append('- Clean filters and check emitter/sprinkler uniformity monthly.')
    return '\n'.join(lines)

def advise(inp: Inputs) -> Dict:
    scores = _score_method(inp)
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    top3 = ranked[:3]
    water_need_mm = _estimate_water_need_mm(inp)
    area_m2 = inp.area_ha * 10_000
    volume_m3 = round((water_need_mm / 1000.0) * area_m2, 1)
    recs = []
    for method, score in top3:
        recs.append({
            'method': method,
            'score': round(score, 2),
            'why': _method_notes(method),
            'starter_kit': _starter_kit(method, inp)
        })
    report = _as_report(inp, water_need_mm, volume_m3, recs)
    return {
        'ranking': recs,
        'water_need_mm': water_need_mm,
        'seasonal_volume_m3': volume_m3,
        'report_text': report,
    }