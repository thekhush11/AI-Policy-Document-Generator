from fastapi import APIRouter
from fastapi.responses import JSONResponse
from app.services.advisor import Inputs, advise, _estimate_avg_rain
from app.utils.docx_export import to_docx_bytes
import base64

api_router = APIRouter()

@api_router.post("/advise")
async def get_advice(data: dict):
    try:
        avg_rain = _estimate_avg_rain(
            region=data.get("region") or "", 
            input_rain=float(data.get("avg_rain_mm") or 0)
        )

        inp = Inputs(
            crop=data.get("crop") or "",
            region=data.get("region") or "",
            area_ha=float(data.get("area_ha") or 1.0),
            soil=data.get("soil") or "Loam",
            slope=data.get("slope") or "Flat",
            avg_rain_mm=avg_rain,
            water_source=data.get("water_source") or "Canal",
            budget_level=data.get("budget_level") or "Medium",
            labor_level=data.get("labor_level") or "Medium",
            salinity=data.get("salinity") or "Low",
            objective=data.get("objective") or "Save Water",
        )

        result = advise(inp)

        docx_bytes = to_docx_bytes({
            "summary": result['report_text'],
            "methods": [
                {"name": r['method'], "description": '\n'.join(r['why'])}
                for r in result['ranking']
            ]
        })
        docx_base64 = base64.b64encode(docx_bytes).decode()

        response = {
            "water_need_mm": result['water_need_mm'],
            "seasonal_volume_m3": result['seasonal_volume_m3'],
            "ranking": result['ranking'],
            "docx_base64": docx_base64,
        }

        return response

    except Exception as e:
        return JSONResponse(status_code=422, content={"detail": str(e)})