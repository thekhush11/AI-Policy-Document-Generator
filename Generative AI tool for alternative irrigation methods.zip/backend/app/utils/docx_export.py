from docx import Document
from datetime import datetime
import io

def to_docx_bytes(policy_data):
    doc = Document()
    doc.add_heading("Irrigation Advisory", 0)

    # Add generation date
    doc.add_paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    doc.add_paragraph("")

    # Add summary
    if "summary" in policy_data:
        doc.add_heading("Summary", level=1)
        doc.add_paragraph(policy_data["summary"])

    # Add methods
    if "methods" in policy_data:
        doc.add_heading("Alternative Irrigation Methods", level=1)
        for idx, method in enumerate(policy_data["methods"], start=1):
            doc.add_heading(f"{idx}. {method['name']}", level=2)
            doc.add_paragraph(method["description"])

    # Save document in memory (bytes)
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()