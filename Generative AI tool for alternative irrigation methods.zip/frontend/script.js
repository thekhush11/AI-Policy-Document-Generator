const API = "http://127.0.0.1:8000/api/advise";

const form = document.getElementById('adviseForm');
const resultBox = document.getElementById('result');
const summaryEl = document.getElementById('summary');
const topMethodsEl = document.getElementById('topMethods');
const downloadEl = document.getElementById('download');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

    const payload = {
    crop: document.getElementById('crop').value,
    region: document.getElementById('region').value,
    area_ha: parseFloat(document.getElementById('area').value),
    soil: document.getElementById('soil').value,
    slope: document.getElementById('slope').value,
    avg_rain_mm: parseFloat(document.getElementById('rain').value),
    water_source: document.getElementById('source').value,
    budget_level: document.getElementById('budget').value,
    labor_level: document.getElementById('labor').value,
    salinity: document.getElementById('salinity').value,
    objective: document.getElementById('objective').value,
  };


  summaryEl.textContent = 'Generating advisory...';
  topMethodsEl.innerHTML = '';
  downloadEl.innerHTML = '';
  resultBox.classList.remove('hidden');

  try {
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `Server ${res.status}`);
    }

    const data = await res.json();

    summaryEl.innerHTML = `
      <p><strong>Seasonal water need:</strong> ${data.water_need_mm} mm</p>
      <p><strong>Seasonal volume:</strong> ${data.seasonal_volume_m3} m³</p>
    `;

    data.ranking.forEach((r, idx) => {
      const div = document.createElement('div');
      div.innerHTML = `
        <h3>${idx + 1}. ${r.method} <small>(score ${r.score})</small></h3>
        <ul>${r.why.map(x => `<li>${x}</li>`).join('')}</ul>
        ${r.starter_kit?.length ? `<p><em>Starter kit:</em></p><ul>${r.starter_kit.map(x => `<li>${x}</li>`).join('')}</ul>` : ''}
      `;
      topMethodsEl.appendChild(div);
    });

    if (data.docx_base64) {
      const btn = document.createElement('button');
      btn.textContent = 'Download Advisory (.docx)';
      btn.addEventListener('click', () => {
        const a = document.createElement('a');
        a.href = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + data.docx_base64;
        a.download = 'irrigation_advisory.docx';
        document.body.appendChild(a);
        a.click();
        a.remove();
      });
      downloadEl.appendChild(btn);
    }

  } catch (err) {
    summaryEl.textContent = 'Error: ' + err.message;
  }
});